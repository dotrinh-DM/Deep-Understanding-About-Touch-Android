package com.example.myapplication;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    String TAG = "fix";

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        GroupARelativeLayout gra = findViewById(R.id.groupA);
//        GroupBRelativeLayout grb = findViewById(R.id.groupB);
        ViewC vc = findViewById(R.id.viewC);

        vc.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Log.i("event 1111", "group C in activity");
                return false;
            }
        });


    }
}
